﻿using UIKit;

namespace Customcheckboxdemo
{
    public class Customchecbox : UIStackView
    {
     

        public Customchecbox()
        {
            Init();

        }

        void Init()
        {
          
            }
    }
}